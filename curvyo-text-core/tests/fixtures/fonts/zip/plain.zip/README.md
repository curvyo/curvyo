# Hershey Sans 1-stroke

A test archive.
